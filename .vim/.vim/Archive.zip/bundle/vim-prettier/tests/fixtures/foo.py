def foo(a, 
        *, 
        example=False, **kwargs):
    print(
            "hello world", 
            example
            )
def i18n_patterns(
        *urls, 
        prefix_default_language=True
        ):
    pass
