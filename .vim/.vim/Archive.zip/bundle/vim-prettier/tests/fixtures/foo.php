<?php
  $a='a';

      $b = $a. $a .' asda';
