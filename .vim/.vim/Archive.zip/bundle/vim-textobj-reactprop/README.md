React Prop Vim Text Object
==========================

Depends on [vim-textobj-user](https://github.com/kana/vim-textobj-user).

This is still in an early stage.
If you want to try it out and give suggestions feel free!

TODO:

* Tests would be nice
* Finalize the design - I'm not convinced the current way it works is the nicest possible
* Docs

Demos
=====

`var`

![](pics/vimdemo.gif)

`cir`

![](pics/vimdemo2.gif)
