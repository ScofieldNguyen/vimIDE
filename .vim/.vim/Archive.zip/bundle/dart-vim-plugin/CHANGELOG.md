#### 0.2.1
   * Added `DartAnalyzer` and `Dart2Js`.
   * Renamed `DartFormat` to `DartFmt`.

#### 0.2.0
   * `dartformat` renamed to `dartfmt`.

#### 0.1.1
   * Added DartFormat command.

#### 0.1.0
   * Added CHANGELOG.md.
   * Added CONTRIBUTING.md.
   * Added support for async, await, yield keywords.
   * Added triple-slash (doc comment) to accepted comment formats.
