# This file is part of nvimcom R package
#
# It is distributed under the GNU General Public License.
# See the file ../LICENSE for details.
#
# (c) 2011 Jakson Aquino: jalvesaq@gmail.com
#
###############################################################

NvimcomEnv <- new.env()
NvimcomEnv$pkgdescr <- list()

.onLoad <- function(libname, pkgname) {
    if(Sys.getenv("NVIMR_TMPDIR") == "")
        return(invisible(NULL))
    library.dynam("nvimcom", pkgname, libname, local = FALSE)

    if(is.null(getOption("nvimcom.verbose")))
        options(nvimcom.verbose = 0)

    # The remaining options are set by Neovim. Don't try to set them in your
    # ~/.Rprofile because they will be overridden here:
    if(file.exists(paste0(Sys.getenv("NVIMR_TMPDIR"), "/start_options.R"))){
        source(paste0(Sys.getenv("NVIMR_TMPDIR"), "/start_options.R"))
    } else {
        options(nvimcom.allnames = FALSE)
        options(nvimcom.texerrs = TRUE)
        options(nvimcom.setwidth = TRUE)
        options(nvimcom.nvimpager = TRUE)
        options(nvimcom.delim = "\t")
    }
    if(getOption("nvimcom.nvimpager"))
        options(pager = nvim.hmsg)
}

.onAttach <- function(libname, pkgname) {
    if(Sys.getenv("NVIMR_TMPDIR") == "")
        return(invisible(NULL))
    if(version$os == "mingw32")
        termenv <- "MinGW"
    else
        termenv <- Sys.getenv("TERM")

    if(interactive() && termenv != "" && termenv != "dumb" && Sys.getenv("NVIMR_COMPLDIR") != ""){
        dir.create(Sys.getenv("NVIMR_COMPLDIR"), showWarnings = FALSE)
        .C("nvimcom_Start",
           as.integer(getOption("nvimcom.verbose")),
           as.integer(getOption("nvimcom.allnames")),
           as.integer(getOption("nvimcom.setwidth")),
           path.package("nvimcom"),
           as.character(utils::packageVersion("nvimcom")),
           paste(paste0(version$major, ".", version$minor),
                  getOption("OutDec"),
                  gsub("\n", "#N#", getOption("prompt")),
                  getOption("continue"),
                  paste(.packages(), collapse = " "),
                  sep = "\x02"),
           PACKAGE="nvimcom")
    }
    if(!is.na(utils::localeToCharset()[1]) && utils::localeToCharset()[1] == "UTF-8" && version$os != "cygwin")
        NvimcomEnv$isAscii <- FALSE
    else
        NvimcomEnv$isAscii <- TRUE
}

.onUnload <- function(libpath) {
    if(is.loaded("nvimcom_Stop", PACKAGE = "nvimcom")){
        .C("nvimcom_Stop", PACKAGE="nvimcom")
        if(Sys.getenv("NVIMR_TMPDIR") != "" && .Platform$OS.type == "windows"){
                unlink(paste0(Sys.getenv("NVIMR_TMPDIR"), "/rconsole_hwnd_",
                              Sys.getenv("NVIMR_SECRET")))
        }
        Sys.sleep(0.2)
        library.dynam.unload("nvimcom", libpath)
    }
}

nvim.edit <- function(name, file, title)
{
    if(file != "")
        stop("Feature not implemented. Use nvim to edit files.")
    if(is.null(name))
        stop("Feature not implemented. Use nvim to create R objects from scratch.")

    waitf <- paste0(Sys.getenv("NVIMR_TMPDIR"), "/edit_", Sys.getenv("NVIMR_ID"), "_wait")
    editf <- paste0(Sys.getenv("NVIMR_TMPDIR"), "/edit_", Sys.getenv("NVIMR_ID"))
    unlink(editf)
    writeLines(text = "Waiting...", con = waitf)

    initial = paste0(Sys.getenv("NVIMR_TMPDIR"), "/nvimcom_edit_", round(runif(1, min = 100, max = 999)))
    sink(initial)
    dput(name)
    sink()

    .C("nvimcom_msg_to_nvim",
       paste0("EditRObject('", initial, "')"),
       PACKAGE="nvimcom")

    while(file.exists(waitf))
        Sys.sleep(1)
    x <- eval(parse(editf))
    unlink(initial)
    unlink(editf)
    x
}

vi <- function(name = NULL, file = "")
{
    nvim.edit(name, file)
}

nvim_capture_source_output <- function(s, o)
{
    capture.output(base::source(s, echo = TRUE), file = o)
    .C("nvimcom_msg_to_nvim", paste0("GetROutput('", o, "')"), PACKAGE="nvimcom")
}

nvim_dput <- function(oname, howto = "tabnew")
{
    sink(paste0(Sys.getenv("NVIMR_TMPDIR"), "/Rinsert"))
    eval(parse(text = paste0("dput(", oname, ")")))
    sink()
    .C("nvimcom_msg_to_nvim",
       paste0('ShowRObj("', howto, '", "', oname, '", "r")'),
       PACKAGE="nvimcom")
}

nvim_viewobj <- function(oname, fenc = "", nrows = NULL, howto = "tabnew", R_df_viewer = NULL)
{
    if(is.data.frame(oname) || is.matrix(oname)){
        # Only when the rkeyword includes "::"
        o <- oname
        oname <- sub("::", "_", deparse(substitute(oname)))
    } else {
        oname_split <- unlist(strsplit(oname, "$", fixed = TRUE))
        oname_split <- unlist(strsplit(oname_split, "[[", fixed = TRUE))
        oname_split <- unlist(strsplit(oname_split, "]]", fixed = TRUE))
        ok <- try(o <- get(oname_split[[1]], envir = .GlobalEnv), silent = TRUE)
        if(length(oname_split) > 1){
            for (i in 2:length(oname_split)) {
                oname_integer <- suppressWarnings(o <- as.integer(oname_split[[i]]))
                if(is.na(oname_integer)){
                    ok <- try(o <- ok[[oname_split[[i]]]], silent = TRUE)
                } else {
                    ok <- try(o <- ok[[oname_integer]], silent = TRUE)
                }
            }
        }
        if(inherits(ok, "try-error")){
            .C("nvimcom_msg_to_nvim",
               paste0("RWarningMsg('", '"', oname, '"', " not found in .GlobalEnv')"),
               PACKAGE="nvimcom")
            return(invisible(NULL))
        }
    }
    if(is.data.frame(o) || is.matrix(o)){
        if(!is.null(nrows)){
          o <- head(o, n = nrows)
        }
        if(!is.null(R_df_viewer)){
            .C("nvimcom_msg_to_nvim",
               paste0("g:SendCmdToR(printf(g:R_df_viewer, '", oname, "'))"),
               PACKAGE="nvimcom")
            return(invisible(NULL))
        }
        if(getOption("nvimcom.delim") == "\t"){
            write.table(o, sep = "\t", row.names = FALSE, quote = FALSE,
                        fileEncoding = fenc,
                        file = paste0(Sys.getenv("NVIMR_TMPDIR"), "/Rinsert"))
        } else {
            write.table(o, sep = getOption("nvimcom.delim"), row.names = FALSE,
                        fileEncoding = fenc,
                        file = paste0(Sys.getenv("NVIMR_TMPDIR"), "/Rinsert"))
        }
        .C("nvimcom_msg_to_nvim", paste0("RViewDF('", oname, "', '", howto, "')"), PACKAGE="nvimcom")
    } else {
        nvim_dput(oname, howto)
    }
    return(invisible(NULL))
}

NvimR.source <- function(..., print.eval = TRUE, spaced = FALSE)
{
    if (with(R.Version(), paste(major, minor, sep = '.')) >= '3.4.0') {
        base::source(getOption("nvimcom.source.path"), ..., print.eval = print.eval, spaced = spaced)
    } else {
        base::source(getOption("nvimcom.source.path"), ..., print.eval = print.eval)
    }
}

NvimR.selection <- function(..., local = parent.frame()) NvimR.source(..., local = local)

NvimR.paragraph <- function(..., local = parent.frame()) NvimR.source(..., local = local)

NvimR.block <- function(..., local = parent.frame()) NvimR.source(..., local = local)

NvimR.function <- function(..., local = parent.frame()) NvimR.source(..., local = local)

NvimR.chunk <- function(..., local = parent.frame()) NvimR.source(..., local = local)

source.and.clean <- function(f, ...)
{
    on.exit(unlink(f))
    source(f, ...)
}

nvim_format <- function(l1, l2, wco, sw)
{
    if(is.null(getOption("nvimcom.formatfun"))){
        if("styler" %in% rownames(installed.packages())){
           options(nvimcom.formatfun = "style_text")
        } else {
            if("formatR" %in% rownames(installed.packages())){
                options(nvimcom.formatfun = "tidy_source")
            } else {
                .C("nvimcom_msg_to_nvim",
                   "RWarningMsg('You have to install either formatR or styler in order to run :Rformat')",
                   PACKAGE="nvimcom")
                return(invisible(NULL))
            }
        }
    }

    if(getOption("nvimcom.formatfun") == "tidy_source"){
        ok <- try(formatR::tidy_source(paste0(Sys.getenv("NVIMR_TMPDIR"), "/unformatted_code"),
                                       file = paste0(Sys.getenv("NVIMR_TMPDIR"), "/formatted_code"),
                                       width.cutoff = wco))
        if(inherits(ok, "try-error")){
            .C("nvimcom_msg_to_nvim",
               "RWarningMsg('Error trying to execute the function formatR::tidy_source()')",
               PACKAGE="nvimcom")
            return(invisible(NULL))
        }
    } else if(getOption("nvimcom.formatfun") == "style_text"){
        txt <- readLines(paste0(Sys.getenv("NVIMR_TMPDIR"), "/unformatted_code"))
        ok <- try(styler::style_text(txt, indent_by = sw))
        if(inherits(ok, "try-error")){
            .C("nvimcom_msg_to_nvim",
               "RWarningMsg('Error trying to execute the function styler::style_text()')",
               PACKAGE="nvimcom")
            return(invisible(NULL))
        }
        writeLines(ok, paste0(Sys.getenv("NVIMR_TMPDIR"), "/formatted_code"))
    }

    .C("nvimcom_msg_to_nvim",
       paste0("FinishRFormatCode(", l1, ", ", l2, ")"),
       PACKAGE="nvimcom")
    return(invisible(NULL))
}

nvim_insert <- function(cmd, howto = "tabnew")
{
    try(ok <- capture.output(cmd, file = paste0(Sys.getenv("NVIMR_TMPDIR"), "/Rinsert")))
    if(inherits(ok, "try-error")){
        .C("nvimcom_msg_to_nvim",
           paste0("RWarningMsg('Error trying to execute the command \"", cmd, "\"')"),
           PACKAGE="nvimcom")
    } else {
        .C("nvimcom_msg_to_nvim",
           paste0('FinishRInsert("', howto, '")'),
           PACKAGE="nvimcom")
    }
    return(invisible(NULL))
}
